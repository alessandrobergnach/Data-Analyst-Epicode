/* Task 2: Descrivi la struttura delle tabelle che reputi utili e sufficienti a modellare lo scenario proposto tramite la sintassi DDL. 
Implementa fisicamente le tabelle utilizzando il DBMS SQL Server (o altro).*/


CREATE TABLE Product
(
ProductID INT, 
ProductName	VARCHAR (25),
CategoryID	VARCHAR (2),
CategoryName VARCHAR (25),
Size	DECIMAL (10,2),
Finishedgood	BIT,
Listprice	DECIMAL (10,2),
Dealerprice	DECIMAL (10,2),
Available BIT, 
CONSTRAINT Pk_ProductID PRIMARY KEY (ProductID),
)

CREATE TABLE Region
(
StateID INT, 
StateName VARCHAR (25), 
RegionID VARCHAR (2), 
RegionName VARCHAR (25),  
CONSTRAINT Pk_StateID PRIMARY KEY (StateID) 
)

CREATE TABLE Sales
(
SalesID	INT,
ProductID INT,
StateID INT,	
Quantity INT,
SalesAmount	DECIMAL (20,2),
SalesDate DATETIME,
CONSTRAINT Pk_SalesID PRIMARY KEY (SalesID), 
CONSTRAINT Fk_ProductID FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
CONSTRAINT Fk_StateID FOREIGN KEY (StateID) REFERENCES Region(StateID),
)


/* Task 3: Popola le tabelle utilizzando dati a tua discrezione (sono sufficienti pochi record per tabella; riporta le query utilizzate) */

INSERT INTO Product (ProductID,ProductName, CategoryID, CategoryName, Size, Finishedgood, Listprice, Dealerprice, Available) 
VALUES 
(1, 'TeddyBear', 'A', 'Toys', 1.1, 1, 5, 10, 1), 
(2, 'Barbie', 'A', 'Toys',  0.8, 1, 18, 25, 1), 
(3, 'Nintendo', 'B', 'Games', 0.6, 1, 150, 200, 1), 
(4, 'Gameboy', 'B', 'Games', 2.1, 1, 50, 100, 0), 
(5, 'Playstation','B', 'Games', 2.4, 1, 200, 250, 1), 
(6,  'Cable', 'C', 'SpareParts', 3.5, 0, 1, 5, 1), 
(7, 'Case', 'D', 'Accessories', 0.5, 1, 10, 30, 1);


INSERT INTO Region (StateID, StateName, RegionID, RegionName)
VALUES
(10, 'Italy', 'EU', 'Europe'),
(11, 'France', 'EU', 'Europe'),
(12, 'UK', 'EU', 'Europe'), 
(22, 'China', 'FE', 'Far East'),
(24, 'Singapore', 'FE', 'Far East'),
(31, 'US', 'NA', 'North America'),
(32, 'Canada', 'NA', 'North America');


INSERT INTO Sales (SalesID, ProductID, StateID, Quantity, SalesAmount, SalesDate)
VALUES 
(1, 1, 22, 3, 14, '26/01/24'),
(2, 1, 10, 4, 20, '01/01/24'), 
(3, 2, 31, 7, 126, '25/12/23'), 
(4, 2, 11, 3, 54, '01/04/23'),
(5, 3, 31, 9, 1350, '31/12/22'),
(6, 5, 32, 8, 1280, '13/09/22');





